package controllers;

import play.mvc.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

import models.*;
import models.users.*;
import views.html.*;


/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller{

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    private FormFactory formFactory;
    private Environment e;
    
        @Inject
        public HomeController(FormFactory f,Environment env) {
            this.formFactory = f;
            this.e = env;
        }
    
        public Result index(Long cat) {
            List<user> userList = null;
            List<project> projectList = project.findAll();
            if (cat == 0) {
                userList = user.findAll();
            }
            else {
                userList = project.find.ref(cat).getusers();
            }
            return ok(index.render(userList, projectList, User.getUserById(session().get("email")),e));
        }

    public Result customer() {
        List<Customer> customerList = Customer.findAll();
        return ok(customer.render(customerList,User.getUserById(session().get("email"))));
    }
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    public Result adduser() {
        Form<user> userForm = formFactory.form(user.class);
        return ok(adduser.render(userForm, User.getUserById(session().get("email"))));
    }
    public Result adduserSubmit() {
        user newuser;
        Form<user> newuserForm = formFactory.form(user.class).bindFromRequest();

        if (newuserForm.hasErrors()) {
            return badRequest(adduser.render(newuserForm, User.getUserById(session().get("email"))));
        }
        else {
            newuser = newuserForm.get();

            if (newuser.getId() == null) {
                newuser.save();    
                flash("success", "user " + newuser.getName() + " was added");
                
            }
            else if (newuser.getId() != null) {
                newuser.update();
                flash("success", "user " + newuser.getName() + " was updated");
            }
        }

        MultipartFormData data = request().body().asMultipartFormData();
        FilePart<File> image = data.getFile("upload");

        String saveImageMsg = saveFile(newuser.getId(), image);

        flash("success", "user " + newuser.getName() + " has been created/updated " + saveImageMsg);

        return redirect(controllers.routes.HomeController.index(0));
    }
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result addDepartment() {
        Form<Department> departmentForm = formFactory.form(Department.class);
        return ok(addDepartment.render(departmentForm,User.getUserById(session().get("email"))));
    }

    public Result addDepartmentSubmit() {
        Form<Department> newDepartmentForm = formFactory.form(Department.class).bindFromRequest();
        

        if (newDepartmentForm.hasErrors()) {
            return badRequest(addDepartment.render(newDepartmentForm,User.getUserById(session().get("email"))));
            
        } 
        else {
            Department newDepartment = newDepartmentForm.get();
            
            if (newDepartment.getId() == null) {
                newDepartment.save();
                flash("success", "Department " + newDepartment.getName() + " was added");                
            }

            else {
                newDepartment.update();
                flash("success", "Department " + newDepartment.getName() + " was updated");                
            }



            return redirect(controllers.routes.HomeController.department());
        }
    }
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result deleteuser(Long id) {
        user.find.ref(id).delete();

        flash("success", "user has been deleted");
        
        return redirect(routes.HomeController.index(0));
    }
    public Result deleteDepartment(Long id) {
        Customer.find.ref(id).delete();
        flash("success", "Department has been deleted");

        return redirect(routes.HomeController.index(0));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result updateuser(Long id) {
        user u;
        Form<user> userForm;

        try {
            p = user.find.byId(id);
            userForm = formFactory.form(user.class).fill(p);
        } 
        catch (Exception ex) {
            return badRequest("error");
        }
        return ok(adduser.render(userForm,User.getUserById(session().get("email"))));
    }
    @Transactional
    public Result updateCustomer(Long id) {        
        Department d;
        Form<Customer> customerForm;

        try {
            d = Department.find.byId(id);
            departmentForm = formFactory.form(Department.class).fill(d);
        }
        catch (Exception ex) {
            return badRequest("error");
        }

        return ok(addDepartment.render(departmentForm,User.getUserById(session().get("email"))));
    }
    public String saveFile(Long id, FilePart<File> uploaded) {
        // make sure that the file exists
        if (uploaded != null) {
            // make sure that the content is indeed an image
            String mimeType = uploaded.getContentType(); 
            if (mimeType.startsWith("image/")) {
                // get the file name
                String fileName = uploaded.getFilename();                
                // save the file object (created without a path, File saves
                // the content to a default location, usually the temp or tmp
                // directory)
                File file = uploaded.getFile();
                // create an ImageMagik operation - this object is used to specify
                // the required image processing
                IMOperation op = new IMOperation();
                // add the uploaded image to the operationop.addImage(file.getAbsolutePath());
                op.addImage(file.getAbsolutePath());
                // resize the image using height and width saveFileOld(Long id, FilePart<File> uploaded) {
                op.resize(300, 200);
                // save the image as jpg 
                op.addImage("public/images/userImages/" + id + ".jpg");
                // create another Image Magick operation and repeat the process above to
                // specify how a thumbnail image should be processed - size 60px
                IMOperation thumb = new IMOperation();
                thumb.addImage(file.getAbsolutePath());
                thumb.resize(60);
                thumb.addImage("public/images/userImages/thumbnails/" + id + ".jpg");
                // we must make sure that the directories exist before running the operations
                File dir = new File("public/images/userImages/thumbnails/");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                // now we create an Image Magick command and execute the operations
                ConvertCmd cmd = new ConvertCmd();
                try {
                    cmd.run(op);
                    cmd.run(thumb);
                } catch(Exception e) {
                    e.printStackTrace();
                }
                return " and image saved";
            }
        }
        return "/ no file";
    }
    public String saveFileOld(Long id, FilePart<File> uploaded) {
        // make sure that the file exists
        String mimeType = uploaded.getContentType(); 
        if (uploaded != null) {
            // make sure that the content is indeed an image
            if (mimeType.startsWith("image/")) {
                // get the file name
                String fileName = uploaded.getFilename();      
                String extension = "";
                int i = fileName.lastIndexOf('.');
                if (i >= 0) {
                    extension = fileName.substring(i+1);
                }
                // save the file object (created without a path, File saves
                // the content to a default location, usually the temp or tmp
                // directory)
                File file = uploaded.getFile();
                // we must make sure that the directory for the images exists before we save it
                File dir = new File("public/images/userImages");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                // move the file to the required location (in a real application 
                // the path to where images are stored would be configurable, but 
                // for the lab we just hard-code it)
                if(file.renameTo(new File("public/images/userImages/", id + "." + extension))) {
                    return "/ file uploaded";
                } else {
                    return "/ file upload failed";
                }
            }
        }
        return "/ no file";
    }

    public Result addProject(){
        Form<Project> projectForm = formFactory.form(Project.class)
        return ok(addproject.render(projectForm));
    }
    public Result addProjectSubmit(){
        Form<Project> newProjectForm = formFactory.form(Project.class).bindFromRequest();

        if(newProjectForm.hasErrors()){
            return badRequest(addProject.render(newProjectForm));
        }else{
            Project newProject = newProjectForm.get();
            if(newProject.getId()== null){
                newProject.save();
            }
            else if(newProject.getId()!=null){
                newProject.update();
            }
            flash("success", "Product"+ newProject.getName() + "was added");
            return redirect(controllers.routes.HomeController.index());



        }

    }

    public Result deleteProject(Long id){
        Project.find.ref(id).delete();
        flash("success", "Project has been deleted");
        return redirect(routes.HomeController.index());
    }
    @Transactional
    public Result updateProject(Long id){
        Project p;
        Form<Project> projectForm;

        try{
            p= Project.find.byId(id);
            projectForm = formFactory.form(Project.class).fill(p);

        }catch (Exception ex){
            return badRequest("error");
        }
        return ok(addProject.render(projectForm));
    }

    public Result userDetails(Long id) {
        User u;

        u = user.find.byId(id);
            
        return ok(userDetails.render(p,User.getUserById(session().get("email")),e));
    }

}
