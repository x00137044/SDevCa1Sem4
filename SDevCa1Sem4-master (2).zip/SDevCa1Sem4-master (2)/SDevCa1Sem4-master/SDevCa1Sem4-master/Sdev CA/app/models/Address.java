package models.users;

import java.util.*;
import javax.persisence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Address extends Model{

    @Id
    private Long id;

    @constraint.Required
    private String address;

    @OneToOne
    private Employee employee;
    public address(){

    }

    public Address(Long id, String address, Employee employee){
        this.id = id;
        this.address = address;
        this.employee=employee;
    }
    public Long getId(){
        return id;
    }

    public void setId(Long id){
        this.id = id;
    }

    public String getAddress(){
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public Employee getEmployee(){
        return employee;
    } 

    public void setEmployee(Employee employee)[
        this.employee = employee;
    ]

    public static List<Address> findAll(){
        return Address.find.query().where.orderBy("id asc").findList();
    }

}