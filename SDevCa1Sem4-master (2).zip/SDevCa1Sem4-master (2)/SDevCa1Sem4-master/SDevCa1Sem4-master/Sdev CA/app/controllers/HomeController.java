package controllers;

import play.mvc.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

import models.*;
import models.users.*;
import views.html.*;


/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller{

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    private FormFactory formFactory;
    private Environment e;
    
        @Inject
        public HomeController(FormFactory f,Environment env) {
            this.formFactory = f;
            this.e = env;
        }
    
        public Result index(Long cat) {
            List<Employee> EmployeeList = null;
            List<Project> projectList = Project.findAll();
            if (cat == 0) {
                EmployeeList = Employee.findAll();
            }
            else {
                EmployeeList = project.find.ref(cat).getEmployees();
            }
            return ok(index.render(EmployeeList, projectList, Employee.getEmployeeById(session().get("email")),e));
        }

   
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    public Result addEmployee() {
        Form<Employee> EmployeeForm = formFactory.form(Employee.class);
        return ok(addEmployee.render(EmployeeForm, User.getUserById(session().get("email"))));
    }
    public Result addEmployeeSubmit() {
        Employee newEmployee;
        Form<Employee> newEmployeeForm = formFactory.form(Employee.class).bindFromRequest();

        if (newEmployeeForm.hasErrors()) {
            return badRequest(addEmployee.render(newEmployeeForm, User.getUserById(session().get("email"))));
        }
        else {
            newEmployee = newEmployeeForm.get();

            if (newEmployee.getId() == null) {
                newEmployee.save();    
                flash("success", "Employee " + newEmployee.getName() + " was added");
                
            }
            else if (newEmployee.getId() != null) {
                newEmployee.update();
                flash("success", "Employee " + newEmployee.getName() + " was updated");
            }
        }

        MultipartFormData data = request().body().asMultipartFormData();
        FilePart<File> image = data.getFile("upload");

        String saveImageMsg = saveFile(newEmployee.getId(), image);

        flash("success", "Employee " + newEmployee.getFName() + ""+ newEmployee.getLname()+" has been created/updated " + saveImageMsg);

        return redirect(controllers.routes.HomeController.index(0));
    }
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result addAddress() {
        Form<Address> AddressForm = formFactory.form(Address.class);
        return ok(addAddress.render(AddressForm,Employee.getEmployeeById(session().get("email"))));
    }

    public Result addAddressSubmit() {
        Form<Address> newAddressForm = formFactory.form(Address.class).bindFromRequest();
        

        if (newAddressForm.hasErrors()) {
            return badRequest(addAddress.render(newAddressForm,Employee.getEmployeeById(session().get("email"))));
            
        } 
        else {
            Address newAddress = newAddressForm.get();
            
            if (newAddress.getId() == null) {
                newAddress.save();
                flash("success", "Address " + newAddress.getName() + " was added");                
            }

            else {
                newAddress.update();
                flash("success", "Address " + newAddress.getName() + " was updated");                
            }



            return redirect(controllers.routes.HomeController.Address());
        }
    }
    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result deleteEmployee(Long id) {
        Employee.find.ref(id).delete();

        flash("success", "Employee has been deleted");
        
        return redirect(routes.HomeController.index(0));
    }
    public Result deleteAddress(Long id) {
        Customer.find.ref(id).delete();
        flash("success", "Address has been deleted");

        return redirect(routes.HomeController.index(0));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result updateEmployee(Long id) {
        Employee e;
        Form<Employee> EmployeeForm;

        try {
            e = Employee.find.byId(id);
            EmployeeForm = formFactory.form(Employee.class).fill(e);
        } 
        catch (Exception ex) {
            return badRequest("error");
        }
        return ok(addEmployee.render(EmployeeForm,User.getUserById(session().get("email"))));
    }
    public String saveFile(Long id, FilePart<File> uploaded) {
        // make sure that the file exists
        if (uploaded != null) {
            // make sure that the content is indeed an image
            String mimeType = uploaded.getContentType(); 
            if (mimeType.startsWith("image/")) {
                // get the file name
                String fileName = uploaded.getFilename();                
                // save the file object (created without a path, File saves
                // the content to a default location, usually the temp or tmp
                // directory)
                File file = uploaded.getFile();
                // create an ImageMagik operation - this object is used to specify
                // the required image processing
                IMOperation op = new IMOperation();
                // add the uploaded image to the operationop.addImage(file.getAbsolutePath());
                op.addImage(file.getAbsolutePath());
                // resize the image using height and width saveFileOld(Long id, FilePart<File> uploaded) {
                op.resize(300, 200);
                // save the image as jpg 
                op.addImage("public/images/EmployeeImages/" + id + ".jpg");
                // create another Image Magick operation and repeat the process above to
                // specify how a thumbnail image should be processed - size 60px
                IMOperation thumb = new IMOperation();
                thumb.addImage(file.getAbsolutePath());
                thumb.resize(60);
                thumb.addImage("public/images/EmployeeImages/thumbnails/" + id + ".jpg");
                // we must make sure that the directories exist before running the operations
                File dir = new File("public/images/EmployeeImages/thumbnails/");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                // now we create an Image Magick command and execute the operations
                ConvertCmd cmd = new ConvertCmd();
                try {
                    cmd.run(op);
                    cmd.run(thumb);
                } catch(Exception e) {
                    e.printStackTrace();
                }
                return " and image saved";
            }
        }
        return "/ no file";
    }
    public String saveFileOld(Long id, FilePart<File> uploaded) {
        // make sure that the file exists
        String mimeType = uploaded.getContentType(); 
        if (uploaded != null) {
            // make sure that the content is indeed an image
            if (mimeType.startsWith("image/")) {
                // get the file name
                String fileName = uploaded.getFilename();      
                String extension = "";
                int i = fileName.lastIndexOf('.');
                if (i >= 0) {
                    extension = fileName.substring(i+1);
                }
                // save the file object (created without a path, File saves
                // the content to a default location, usually the temp or tmp
                // directory)
                File file = uploaded.getFile();
                // we must make sure that the directory for the images exists before we save it
                File dir = new File("public/images/EmployeeImages");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                // move the file to the required location (in a real application 
                // the path to where images are stored would be configurable, but 
                // for the lab we just hard-code it)
                if(file.renameTo(new File("public/images/EmployeeImages/", id + "." + extension))) {
                    return "/ file uploaded";
                } else {
                    return "/ file upload failed";
                }
            }
        }
        return "/ no file";
    }
    public Result updateEmployeeSubmit(Long id){
        Form<Employee> updateEmployeeForm = formFactory.form(Employee.class).bindFromRequest();

        if(updateEmployeeForm.hasErrors()){
            return ok(updateEmployee.render(id, updateEmployeeForm,User.getUserById(session().get("email"))));
        }else{
            Employee e = updateEmplyeeForm.get();
            e.setId(id);

            List<Project> newProj = new ArrayList<Project>();
            for(Long proj : e.getProjSelect()){
                newProj.add(Project.find.byId(proj));
            }
            e.projects = newProj;

            e.update();

            MultipartFormData data = request().body().asMultipartFormData();
            FilePart<file> image = data.getFile("upload");

            String saveImageMsg = saveFile(e.getId(),image);

            flash("success", "Employee " +e.getFname() + "" + e.getLname()+" has benn updated" + saveImageMsg);
            return redirect(controllers.routes.Homecontroller.index(0));
        }
    }

    public Result EmployeeDetails(Long id) {
        Employee u;

        u = Employee.find.byId(id);
            
        return ok(EmployeeDetails.render(p,Employee.getEmployeeById(session().get("email")),e));
    }

}
