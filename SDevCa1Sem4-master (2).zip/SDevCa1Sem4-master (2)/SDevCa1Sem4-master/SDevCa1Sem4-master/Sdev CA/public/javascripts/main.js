function confirmDel(){
    return confirm('are you sure?');
}