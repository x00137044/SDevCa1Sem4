package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Project extends Model{

@Id
private Long id;
@Constraints.Required
private String name;
@Constraints.Required
private String description;



private String department;

@ManyToMany(cascade = CascadeType.ALL)
public List<Employee> employees;
public Project(){

}

public Project(Long id, String name){
    this.id = id;
    this.name  = name;
}
public String getName(){
    return name;
}
public void setName(String name){
    this.name = name;
}
public String getDescription(){
    return description;
}
public void setDescription(String description){
    this.description = description;
}
public List<Employee> getEmployee(){
    return employee;
}
public void setEmployee(List<Employee> Employee){
    this.employee = Employee;
}
public Long getId(){
    return id;
}
public void setId(Long id){
    this.id = id;
}
public String getDepartment(){
    return department;
}
public void setDepartment(String department){
    this.department = department;
}

public static Map<String, String> options() {
    LinkedHashMap<String, String> options = new LinkedHashMap();

public static Finder<Long, Project> find = new Finder<Long, Project>(Project.class);

public static List<Project> findAll() {
    return Project.find.query().where().orderBy("name asc").findList();
}
return options
}

public static Map<String, String> keys() {
    LinkedHashMap<String, String> keys = new LinkedHashMap();

    for (Project p: Project.findAll()) {
        keys.put(p.getId().toString(), p.getName());
    }
    
    return keys;
}
public static boolean amountInProject(Long project, Long employee){
    return find.query().where()
    .eq("employees.id", employee)
    .eq("id" , project)
    .findCount() > 0;
} 

public void setDeadline(String deadline){
    this.deadline=deadline;
}
public String getDeadline(){
    return this.deadline;
}

}
