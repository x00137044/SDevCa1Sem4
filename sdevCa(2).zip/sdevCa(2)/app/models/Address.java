package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Address extends Model{

    @Id
    private Long id;

    @Constraints.Required
    private String street;

    @Constriants.Required
    private String county;

    @Constriants.Required
    private String country;


    public address(){

    }

    public Address(Long id, String street, String county, String country){
        this.id = id;
        this.street = street;
        this.county = county;
        this.country = country;
    }
    public Long getId(){
        return id;
    }

    public void setId(Long id){
        this.id = id;
    }

    public String getStreet(){
        return street;
    }

    public void setStreet(String street){
        this.street = street;
    }

    public String getCounty(){
        return county;
    } 

    public void setCounty(String county){
        this.county = county;
}

public String getCountry(){
    return country;
}
public void setCountry(String country){
    this.country = country;
}

public static Finder<Long,Address> find = new Finder<Long, Address>(Address.class);

    public static List<Address> findAll(){
        return Address.find.query().where.orderBy("id asc").findList();
    }

}