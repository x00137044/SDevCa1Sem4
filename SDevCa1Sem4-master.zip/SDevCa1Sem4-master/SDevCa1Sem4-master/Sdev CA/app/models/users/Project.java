package models.users;

public class Project{
    
private String name;
private String description;
private int users;
private String id;

}